// Example FAQ data
const faqData = [
  { question: "What is this website?", answer: "This is an FAQ page for common questions.", category: "general" },
  { question: "How do I reset my password?", answer: "Click 'Forgot Password' on the login page.", category: "technical" },
  { question: "How do I contact support?", answer: "You can contact support via email at support@example.com.", category: "general" },
  { question: "What payment methods are accepted?", answer: "We accept Visa, Mastercard, and PayPal.", category: "billing" },
  { question: "How do I cancel my subscription?", answer: "Go to the account settings and click 'Cancel Subscription'.", category: "billing" },
];

// Render FAQ items
const faqList = document.getElementById("faq-list");
const renderFaqs = (faqs) => {
  faqList.innerHTML = "";
  faqs.forEach((faq, index) => {
    const faqItem = document.createElement("div");
    faqItem.classList.add("faq-item");
    faqItem.innerHTML = `
      <div class="faq-question" data-index="${index}">
        <span>${faq.question}</span>
        <span>+</span>
      </div>
      <div class="faq-answer">${faq.answer}</div>
    `;
    faqList.appendChild(faqItem);
  });
};

// Filter by category
const categoryButtons = document.querySelectorAll(".category-btn");
categoryButtons.forEach((button) => {
  button.addEventListener("click", () => {
    categoryButtons.forEach((btn) => btn.classList.remove("active"));
    button.classList.add("active");

    const category = button.getAttribute("data-category");
    const filteredFaqs =
      category === "all"
        ? faqData
        : faqData.filter((faq) => faq.category === category);
    renderFaqs(filteredFaqs);
  });
});

// Toggle FAQ answers
faqList.addEventListener("click", (event) => {
  if (event.target.classList.contains("faq-question")) {
    const answer = event.target.nextElementSibling;
    answer.classList.toggle("visible");
    event.target.querySelector("span:last-child").textContent = answer.classList.contains("visible") ? "-" : "+";
  }
});

// Search FAQs
const searchInput = document.getElementById("faq-search");
searchInput.addEventListener("input", (event) => {
  const searchTerm = event.target.value.toLowerCase();
  const filteredFaqs = faqData.filter((faq) =>
    faq.question.toLowerCase().includes(searchTerm)
  );
  renderFaqs(filteredFaqs);
});

// Initial render
renderFaqs(faqData);

