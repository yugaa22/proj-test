const API_KEY = 'bd5e378503939ddaee76f12ad7a97608'; // Replace with your weather API key

document.getElementById('search-btn').addEventListener('click', async () => {
  const location = document.getElementById('location-search').value;
  if (!location) {
    alert('Please enter a location.');
    return;
  }

  try {
    // Fetch current weather data
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${API_KEY}&units=metric`
    );
    if (!response.ok) {
      throw new Error('Location not found.');
    }
    const data = await response.json();
    updateWeatherDisplay(data);
  } catch (error) {
    alert(error.message);
  }
});

function updateWeatherDisplay(data) {
  document.getElementById('city-name').textContent = data.name;
  document.getElementById('temperature').textContent = `Temperature: ${data.main.temp}°C`;
  document.getElementById('description').textContent = `Description: ${data.weather[0].description}`;
  document.getElementById('humidity').textContent = `Humidity: ${data.main.humidity}%`;
  document.getElementById('wind-speed').textContent = `Wind Speed: ${data.wind.speed} m/s`;

  // Update the chart with weather data
  updateWeatherChart(data);
}

function updateWeatherChart(data) {
  const ctx = document.getElementById('weather-chart').getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Temperature', 'Feels Like', 'Min Temp', 'Max Temp'],
      datasets: [
        {
          label: 'Temperature (°C)',
          data: [
            data.main.temp,
            data.main.feels_like,
            data.main.temp_min,
            data.main.temp_max,
          ],
          backgroundColor: ['#ff9800', '#ff5722', '#03a9f4', '#8bc34a'],
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
}

