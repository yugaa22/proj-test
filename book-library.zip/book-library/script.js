// Example book data
const books = [
  { title: "The Great Gatsby", category: "fiction" },
  { title: "A Brief History of Time", category: "science" },
  { title: "Sapiens", category: "non-fiction" },
  { title: "1984", category: "fiction" },
  { title: "The Selfish Gene", category: "science" },
  { title: "Educated", category: "non-fiction" },
  { title: "To Kill a Mockingbird", category: "fiction" },
];

// Keep track of the reading list
let readingListItems = new Set();

// Render book cards
const bookList = document.getElementById("book-list");
const renderBooks = (bookArray) => {
  bookList.innerHTML = "";
  bookArray.forEach((book) => {
    const bookCard = document.createElement("div");
    bookCard.classList.add("book-card");
    bookCard.innerHTML = `
      <h3>${book.title}</h3>
      <p>Category: ${book.category}</p>
      <button data-title="${book.title}">Add to Reading List</button>
    `;
    bookList.appendChild(bookCard);
  });
};

// Filter books by category
const categoryButtons = document.querySelectorAll(".category-btn");
categoryButtons.forEach((button) => {
  button.addEventListener("click", () => {
    categoryButtons.forEach((btn) => btn.classList.remove("active"));
    button.classList.add("active");

    const category = button.getAttribute("data-category");
    const filteredBooks =
      category === "all" ? books : books.filter((book) => book.category === category);
    renderBooks(filteredBooks);
  });
});

// Search books
const searchInput = document.getElementById("book-search");
searchInput.addEventListener("input", (event) => {
  const searchTerm = event.target.value.toLowerCase();
  const filteredBooks = books.filter((book) =>
    book.title.toLowerCase().includes(searchTerm)
  );
  renderBooks(filteredBooks);
});

// Add to reading list
const readingList = document.getElementById("reading-list-items");
const renderReadingList = () => {
  readingList.innerHTML = "";
  readingListItems.forEach((bookTitle) => {
    const listItem = document.createElement("li");
    listItem.innerHTML = `
      ${bookTitle}
      <button class="remove-btn" data-title="${bookTitle}">Remove</button>
    `;
    readingList.appendChild(listItem);
  });
};

bookList.addEventListener("click", (event) => {
  if (event.target.tagName === "BUTTON") {
    const bookTitle = event.target.getAttribute("data-title");
    if (!readingListItems.has(bookTitle)) {
      readingListItems.add(bookTitle);
      renderReadingList();
    }
  }
});

// Remove from reading list
readingList.addEventListener("click", (event) => {
  if (event.target.classList.contains("remove-btn")) {
    const bookTitle = event.target.getAttribute("data-title");
    readingListItems.delete(bookTitle);
    renderReadingList();
  }
});

// Initial render
renderBooks(books);

