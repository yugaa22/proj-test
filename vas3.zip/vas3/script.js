const API_KEY = 'bd5e378503939ddaee76f12ad7a97608'; // Replace with your OpenWeatherMap API key

document.getElementById('search-btn').addEventListener('click', async () => {
  const location = document.getElementById('location-search').value;
  if (!location) {
    alert('Please enter a location.');
    return;
  }

  try {
    // Fetch current weather data
    const currentWeatherResponse = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${location}&appid=${API_KEY}&units=metric`
    );
    if (!currentWeatherResponse.ok) {
      throw new Error('Location not found.');
    }
    const currentWeatherData = await currentWeatherResponse.json();
    updateWeatherDisplay(currentWeatherData);

    // Fetch 5-day forecast data
    const forecastResponse = await fetch(
      `https://api.openweathermap.org/data/2.5/forecast?q=${location}&appid=${API_KEY}&units=metric`
    );
    if (!forecastResponse.ok) {
      throw new Error('Unable to fetch forecast.');
    }
    const forecastData = await forecastResponse.json();
    updateForecastDisplay(forecastData);
  } catch (error) {
    alert(error.message);
  }
});

function updateWeatherDisplay(data) {
  document.getElementById('city-name').textContent = data.name;
  document.getElementById('temperature').textContent = `Temperature: ${data.main.temp}°C`;
  document.getElementById('description').textContent = `Description: ${data.weather[0].description}`;
  document.getElementById('humidity').textContent = `Humidity: ${data.main.humidity}%`;
  document.getElementById('wind-speed').textContent = `Wind Speed: ${data.wind.speed} m/s`;

  // Update the chart with current weather data
  updateWeatherChart(data);
}

function updateForecastDisplay(data) {
  const forecastContainer = document.getElementById('forecast-container');
  forecastContainer.innerHTML = ''; // Clear previous forecast

  // Filter to get one forecast per day (e.g., midday forecasts)
  const dailyForecasts = data.list.filter((entry) =>
    entry.dt_txt.includes('12:00:00')
  );

  dailyForecasts.forEach((forecast) => {
    const forecastItem = document.createElement('div');
    forecastItem.classList.add('forecast-item');
    forecastItem.innerHTML = `
      <p><strong>${new Date(forecast.dt * 1000).toLocaleDateString()}</strong></p>
      <p>${forecast.weather[0].description}</p>
      <p>Temp: ${forecast.main.temp}°C</p>
      <p>Humidity: ${forecast.main.humidity}%</p>
    `;
    forecastContainer.appendChild(forecastItem);
  });
}

function updateWeatherChart(data) {
  const ctx = document.getElementById('weather-chart').getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Temperature', 'Feels Like', 'Min Temp', 'Max Temp'],
      datasets: [
        {
          label: 'Temperature (°C)',
          data: [
            data.main.temp,
            data.main.feels_like,
            data.main.temp_min,
            data.main.temp_max,
          ],
          backgroundColor: ['#ff9800', '#ff5722', '#03a9f4', '#8bc34a'],
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true,
        },
      },
    },
  });
}

